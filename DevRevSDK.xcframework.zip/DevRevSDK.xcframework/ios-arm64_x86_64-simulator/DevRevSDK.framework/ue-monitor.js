if (typeof window.UserExperiorSDK === 'undefined') {

    let UEPoint;
    /**
     * Define UEPoint if it was not done before.
     */
    if (typeof UEPoint === 'undefined') {
        /**
         * UEPoint class.
         * Represents a single point in the Browser coordinate system.
         */
        UEPoint = class {
            /* attributes */
            #x;
            #y;

            /* constructor */
            /**
             * @constructor
             * @param {Number} a - location on the X-axis of the Browser coordinate system.
             * @param {Number} b - location on the Y-axis of the Browser coordinate system.
             */
            constructor(a, b) {
                this.#x = a;
                this.#y = b;
            }

            /**
             * @returns {Number} location on the X-axis of the Browser coordinate system.
             */
            get x() { return this.#x; }

            /**
             * @returns {Number} location on the Y-axis of the Browser coordinate system.
             */
            get y() { return this.#y; }

            /**
             * Sets a new value for the location on the X-axis of the Browser coordinate system.
             * @param value new value for the location on the X-axis of the Browser coordinate system.
             */
            set x(value) { this.#x = value; };

            /**
             * Sets a new value for the location on the Y-axis of the Browser coordinate system.
             * @param value new value for the location on the Y-axis of the Browser coordinate system.
             */
            set y(value) { this.#y = value; };
        };
    };

    let UEPageMaskLocations;
    /**
     * Define UEPageMaskLocations if it was not done before.
     */
    if (typeof UEPageMaskLocations !== "function") {
        /**
         * UEPageMaskLocations class.
         *
         * Represents the data gathered by the system in a single document.
         * All data is in the Browser coordinate system.
         */
        UEPageMaskLocations = class {

            /* attributes */
            offset;
            elements;

            /**
             * @constructor
             * @param {UEPoint} offset - location on the X-axis of the Browser coordinate system.
             * @param {HTMLElement[]} elements - location on the Y-axis of the Browser coordinate system.
             */
            constructor(offset, elements) {
                this.offset = offset;
                this.elements = elements;
            }
            /**
             * @returns {UEPoint} the offset of the page within the global browser coordinate system.
             */
            get pageOffset() { return this.offset; };
            /**
             * @returns {HTMLElement[]} the elements within the page that should be masked by the UE system.
             */
            get pageElements() { return this.elements; };

            /**
             * @returns {DOMRectReadOnly[]} the locations within the page that should be masked by the UE system.
             *      Represented in the global browser coordinate system.
             */
            get pageLocations() {

				let statusBarHeight = 0
				if (window.cordova) {
					statusBarHeight = window.dynamicStatusBarHeight
				}

                const offset = this.pageOffset;
                return this.pageElements.flatMap(e => {
                    const frameRect = e.getBoundingClientRect();
                    return new DOMRectReadOnly(
                        offset.x + frameRect.left,
						offset.y + statusBarHeight + frameRect.top,
                        frameRect.width,
                        frameRect.height
                    );
                });
            };
        };
    };

    let UEPageContainer;
    /**
     * Define UEPageContainer if it was not done before.
     */
    if (typeof UEPageContainer !== "function") {
        /**
         * UEPageContainer class.
         *
         * Represents the data container associated with a given html document.
         */
        UEPageContainer = class {
            /* attributes */
            DOMObserver;
            DOMDocument;
            DOMChanged;
            DOMSelector;
            data;

            /* constructor */
            /**
             * @constructor
             * @param {Document} elementDocument the monitored html document
             */
            constructor(elementDocument) {
                this.DOMObserver = null;
                this.DOMDocument = elementDocument;
                this.DOMChanged = false;
                this.DOMSelector = undefined;
                this.data = { autoDetected : [], blacklist : [], whitelist : [] };
                /*
                 * Listen to DOM mutation events and mark domChanged for every such event.
                 * This is used in to optimize which DOM elements should be blocked for PII.
                 * So that mask locations will be re-calculated only when DOM actually change.
                 */
                if (MutationObserver) {
                    const self = this;
                    self.DOMObserver = new MutationObserver(function () {
                        self.DOMChanged = true;
                    });
                    self.DOMObserver.observe(self.DOMDocument.documentElement, {
                        subtree: true, childList: true, attributes: true
                    });
                }
            };
            static utilities = {
                /** Mathematics related functionality
                 */
                math : {
                    /**
                     * Rectangle related computations.
                     */
                    rects : {
                        /**
                         * Check if rectangle a contains rectangle b.
                         * @param a {DOMRect} rectangle a
                         * @param b {DOMRect} rectangle b
                         * @returns {boolean} true if rectangle a contains rectangle b.
                         */
                        contains : function (a, b) {
                            return !(
                                b.left < a.left ||
                                b.top < a.top ||
                                b.right > a.right ||
                                b.bottom > a.bottom
                            );
                        },
                        /**
                         * Check if rectangle A overlaps rectangle B.
                         * @param a {DOMRect} rectangle A
                         * @param b {DOMRect} rectangle B
                         * @returns {boolean} true if rectangle A overlaps rectangle B.
                         */
                        overlaps : function (a, b) {
                            /* no horizontal overlap */
                            if (a.left >= b.right || b.left >= a.right) {
                                return false;
                            }
                            /* no vertical overlap */
                            return !(a.top >= b.bottom || b.top >= a.bottom);

                        },
                        /**
                         * Check if rectangle a touches rectangle b.
                         * @param a {DOMRect} rectangle a
                         * @param b {DOMRect} rectangle b
                         * @returns {boolean} true if rectangle a touches rectangle b.
                         */
                        touches : function (a, b) {
                            /* has horizontal gap */
                            if (a.left > b.right || b.left > a.right) {
                                return false;
                            }
                            /* has vertical gap */
                            return !(a.top > b.bottom || b.top > a.bottom);

                        },
                    },
                    /**
                     * Set related computations.
                     */
                    sets  : {
                        /**
                         * Creates a new set, which contains the union of two given sets.
                         * @param {Set<T>} one
                         * @param {Set<T>} two
                         * @returns {Set<T>} new set which contains the union of two given sets.
                         */
                        unite : function (one, two) {
                            let union = new Set(one);
                            for (let element of two) {
                                union.add(element);
                            }
                            return union;
                        },
                        /**
                         * Creates a new set, which contains the minus of two given sets.
                         * @param {Set<T>} one
                         * @param {Set<T>} two
                         * @returns {Set<T>} new set which contains the difference of two sets.
                         */
                        minus : function (one, two) {
                            return new Set(Array.from(one).filter(item => !two.has(item)));
                        },
                    },
                },
                /** JS related functionality
                 */
                js_elements : {
                    /**
                     * Locates all elements of a given class name in a given document
                     * @param {Document} elementDocument document to search
                     * @param {String} className class name we search for
                     * @returns {HTMLElement[]} an array of HTMLElements of a given class name
                     */
                    searchForClass : function(elementDocument, className) {
                        let rawList = elementDocument.getElementsByClassName(className);
                        return Array.prototype.slice.call(rawList);
                    },
                    /**
                     * Locates all white listed elements in a given document
                     * @param {Document} elementDocument document to search
                     * @param {string} selectors a string representing the query selector
                     * @returns {HTMLElement[]} an array of HTMLElements matching the query selector.
                     */
                    searchForSelectors : function(elementDocument, selectors) {
                        let rawList = elementDocument.querySelectorAll(selectors);
                        return Array.prototype.slice.call(rawList);
                    },
                },
                js_search   : {
                    /**
                     * Locates all auto-detected elements in a given document
                     * @param {Document} elementDocument document to search
                     * @returns {HTMLElement[]} an array of auto-detected elements
                     */
                    detected  : function(elementDocument) {

                        const utility = UEPageContainer.utilities;
                        const selectors = "input" +
                            "[type='date'],[type='datetime']," +
                            "[type='datetime-local'],[type='month']," +
                            "[type='text'],[type='email'],[type='number']," +
                            "[type='tel'],[type='file'],[type='password']";

                        return utility.js_elements.searchForSelectors(elementDocument,selectors);
                    },
                    /**
                     * Locates all black listed elements in a given document
                     * @param {Document} elementDocument document to search
                     * @param selectors
                     * @returns {HTMLElement[]} an array of black listed elements
                     */
                    blacklist : function(elementDocument,selectors) {

                        const utility = UEPageContainer.utilities.js_elements;
                        let elements = utility.searchForClass(elementDocument, 'devrev-mask');
                        let domNodes = utility.searchForSelectors(elementDocument, selectors);
                        return Array.prototype.concat(elements , domNodes);
                    },
                    /**
                     * Locates all white listed elements in a given document
                     * @param {Document} elementDocument document to search
                     * @returns {HTMLElement[]}
                     */
                    whitelist : function(elementDocument) {

                        const utility = UEPageContainer.utilities.js_elements;
                        return utility.searchForClass(elementDocument, 'devrev-unmask');
                    },
                },
                js_viewport  : {
                    /**
                     * Checks if a given DOM element is hidden by checking if CSS style hides it.
                     * @param {HTMLElement} element to test
                     * @returns {boolean} true if the element is hidden.
                     */
                    isElementHidden : function(element) {

                        let view = element.ownerDocument.defaultView || window;
                        let style = view.getComputedStyle(element);

                        let isHiddenByStyle =
                            style.getPropertyValue('display') === 'none' ||
                            style.getPropertyValue('visibility') === 'hidden' ||
                            style.getPropertyValue('opacity') === "0";

                        return isHiddenByStyle || element.offsetParent === null ||
                            (!element.offsetWidth  || !element.offsetHeight);
                    },
                    /**
                     * Checks if a given DOM element is within the display viewport.
                     * @param {HTMLElement} element to test
                     * @returns {boolean}
                     */
                    isInViewport : function (element) {

                        /** @type {HTMLElement}
                         */
                        let elementDocument = element.ownerDocument.documentElement;
                        /**
                         * @type {WindowProxy & typeof globalThis}
                         */
                        let defaultView = element.ownerDocument.documentElement.defaultView;
                        let elementRect = element.getBoundingClientRect();
                        let elementWindow = new DOMRect(
                            0,
                            0,
                            defaultView?.innerWidth || elementDocument?.clientWidth,
                            defaultView?.innerHeight || elementDocument?.clientHeight
                        );

                        const rects = UEPageContainer.utilities.math.rects;
                        return rects.contains(elementWindow,elementRect) || rects.overlaps(elementWindow,elementRect);
                    },
                },
            };

            /**
             * @returns {Document} the monitored html document.
             */
            get DOMDocument() { return this.DOMDocument; };
            /**
             * @returns {Set<HTMLElement>} All HTMLElements automatically detected by the UE system rules.
             */
            get autoDetected() { return new Set(this.data.autoDetected); };
            /**
             * @returns {Set<HTMLElement>} All HTMLElements manually white listed.
             */
            get whitelist() { return new Set(this.data.whitelist); };
            /**
             * @returns {Set<HTMLElement>} All HTMLElements manually black listed.
             */
            get blacklist() { return new Set(this.data.blacklist); };
            /**
             * @returns {HTMLElement[]} All HTMLElement that were detected according to the PII rules.
             * Adjusted for blacklist & whitelist.
             */
            allSecuredElements() {
                const self = this;
                const math = UEPageContainer.utilities.math;
                let allSecured = new Set();
                allSecured = math.sets.unite(allSecured, self.autoDetected);
                allSecured = math.sets.minus(allSecured, self.whitelist);
                allSecured = math.sets.unite(allSecured, self.blacklist);
                return Array.from(allSecured);
            };
            /**
             * Trigger a recalculation of the PPI elements to be masked.
             */
            refreshData() {
                const self = this;
                const search = UEPageContainer.utilities.js_search;
                /* Recalculate which DOM elements should be masked, if DOM has changes, or initial calculation was not done before.
                 */
                if (
                    self.DOMChanged || !(self.data.autoDetected || self.data.blacklist || self.data.whitelist) ||
                    (Array.isArray(self.data.autoDetected) && !self.data.autoDetected.length) ||
                    (Array.isArray(self.data.blacklist   ) && !self.data.blacklist.length   ) ||
                    (Array.isArray(self.data.whitelist   ) && !self.data.whitelist.length   )
                ) {
                    self.DOMChanged = false;
                    self.data.autoDetected = search.detected (self.DOMDocument);
                    self.data.blacklist = search.blacklist(self.DOMDocument,self.DOMSelector);
                    self.data.whitelist = search.whitelist(self.DOMDocument);
                }
            };

            /**
             * forces a refresh action
             */
            forceRefreshData() {
                this.DOMChanged = true;
                this.refreshData()
            };
            /**
             * @returns {UEPoint} The offset of the documents defaultView within the global browser coordinate system.
             */
            offsetInBrowser() {

                const self = this;
                let offsets = [];
                let current = self.DOMDocument.defaultView;
                while (current !== null && current !== undefined && current.frameElement !== null && current.frameElement !== undefined) {
                    offsets.push(current.frameElement.getBoundingClientRect());
                    current = current.frameElement.ownerDocument.defaultView;
                };

                let origin = new UEPoint(0, 0);
                offsets.forEach( (e) => {
                    origin.x = origin.x + e.left;
                    origin.y = origin.y + e.top ;
                });
                return origin;
            };
            /**
             * @returns {HTMLElement[]} all secured elements, according to the PII rules, filtered for the Document's viewport.
             */
            elementsToMask() {
                const js_viewport = UEPageContainer.utilities.js_viewport;
                return this.allSecuredElements().filter(function (element) {
                    return !js_viewport.isElementHidden(element) && js_viewport.isInViewport(element);
                });
            };
            /**
             * @returns {UEPageMaskLocations} a data container bucket,
             * containing all the information needed to represent PII locations to mask in global browser coordinate system.
             */
            locationsData() {
                const self = this;
                self.refreshData();
                return new UEPageMaskLocations(self.offsetInBrowser(), self.elementsToMask());
            };
        }
    };

    let UserExperiorSDKType;
    /**
     * Define UserExperiorSDK class.
     */
    if (typeof UserExperiorSDKType === 'undefined') {
        UserExperiorSDKType = class {
            /* attributes */
            DOMChanged;
            monitor   ;
            /** @type {UEPageContainer[]}
             */
            container ;

            /* constructor */
            /**
             * @constructor
             */
            constructor() {
                this.DOMChanged = false;
                this.monitor = {};
                this.container = [];

                /* TODO: Add monitoring to handle adding an removing of iframes */
                /** SDK DOM Mutation Monitoring elements
                 */
                if (MutationObserver) {
                    const self = this;
                    const mo = new MutationObserver(function () {
                        self.DOMChanged = true;
                    });
                    mo.observe(document.documentElement, {subtree: true, childList: true, attributes: true});
                }

                this.refreshContainer();
                this.setupMonitors();
            };
            static utilities = {
                /** DOM related functionality
                 */
                dom : {
                    /**
                     * @param {Document} elementDocument document to search
                     * @returns {Document[]} an array of all documents on a specific HTML page, including iFrames.
                     */
                    docsInDOM : function (elementDocument) {
                        /** @type {HTMLIFrameElement[]}
                         */
                        let iframes = Array.from(elementDocument.getElementsByTagName("iframe"));
                        /** @type {HTMLObjectElement[]}
                         */
                        let objects = Array.from(elementDocument.getElementsByTagName("object"));
                        /** @type {HTMLIFrameElement[]}
                         */
                        let items = iframes.concat(objects);
                        if (Array.isArray(items) && items.length) {
                            return new Array(elementDocument).concat(items.flatMap(e => {
                                return (e.contentDocument === null || e.contentDocument === undefined) ?
                                    [] : UserExperiorSDKType.utilities.dom.docsInDOM(e.contentDocument);
                            }));
                        } else {
                            return new Array(elementDocument);
                        }
                    },
                    documentsInPage : function () {
                        return UserExperiorSDKType.utilities.dom.docsInDOM(document);
                    }
                },
                /** JS related functionality
                 */
                js_utilities : {
                    /**
                     * Returns a string representation of the input rectangles array, encoded according to the platform format
                     *  for iOS     : {{left,top},{width,height}}*...*{{left,top},{width,height}}
                     *  for Android : {origin:{x:e.left,y: e.top},size:{width:e.width,height:e.height}}
                     * If rectangles array is empty function returns an empty string
                     * */
                    serialize : function (rectangles) {
                        const mobileOS = function () {
                            let ua = navigator.userAgent;
                            if (/android/i.test(ua)) {
                                return "Android";
                            } else if (/iPad|iPhone|iPod/.test(ua)) {
                                return "iOS";
                            } else if (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1) {
                                return "iOS";
                            }
                            return "Other"
                        };

                        switch (mobileOS()) {
                            case "Android":
                                return rectangles.flatMap(function (e) {
                                    return {origin:{x:e.left,y: e.top},size:{width:e.width,height:e.height}};
                                });
                            case "iOS":
                                return rectangles.flatMap(function (e) {
                                    return '{{' + e.left + ',' + e.top + '},{' + e.width + ',' + e.height + '}}';
                                }).join('*');
                            default:
                                return "";
                        }
                    },
                },
            };

            /**
             * SDK Main window monitoring
             */
            setupMonitors() {
                const monitor = this.monitor;
                const renewTimeout = function(data) {
                    data.isZooming = 'true';
                    if (data.zoomTimeout) {
                        clearTimeout(data.zoomTimeout);
                    }
                    data.zoomTimeout = setTimeout(function () {
                        data.isZooming = 'false';
                    }, 750);
                }

                if (!monitor.isScrollHandlerInstalled) {
                    monitor.isScrollHandlerInstalled = true;
                    monitor.isScrolling = false;
                    window.addEventListener('scroll', function () {
                        monitor.isScrolling = true;
                        if (monitor.scrollTimeout) {
                            clearTimeout(monitor.scrollTimeout);
                        }
                        monitor.scrollTimeout = setTimeout(function () {
                            monitor.isScrolling = false;
                        }, 750);
                    });
                };

                if (!monitor.isTapActionHandlerInstalled) {
                    monitor.isTapActionHandlerInstalled = true;
                    monitor.isZooming = false;

                    document.body.addEventListener("touchend", function () {
                        let now = new Date().getTime();
                        let lastTouch = monitor.ueLastTouchTimestamp || now + 1;
                        let delta = now - lastTouch;
                        monitor.ueLastTouchTimestamp = now;
                        if (delta > 0 && delta < 50) {
                            renewTimeout(monitor);
                        }
                    });
                }

                if (!monitor.isFocusHandlerInstalled) {
                    monitor.isFocusHandlerInstalled = true;
                    monitor.isZooming = false;
                    document.querySelectorAll('input').forEach(function (e) {
                        e.addEventListener('focus', function () { renewTimeout(monitor); }, false);
                    });
                }
            };

            refreshContainer() {

                /* Recalculate which DOM elements should be masked, if DOM has changes, or initial calculation was not done before.
                 */
                if ( this.DOMChanged || !(this.container) || (Array.isArray(this.container) && !this.container.length) )
                {
                    this.DOMChanged = false;
                    this.container = UserExperiorSDKType.utilities.dom.documentsInPage().flatMap(e => {
                        return new UEPageContainer(e);
                    });
                }
            };

            forceRefreshMaskLocations() {
                this.DOMChanged = true;
                this.refreshContainer();
                this.container.forEach( (e) => {
                    e.forceRefreshData();
                });
            };

            /**
             * Compute masked locations
             * @returns {*|string}
             */
            maskedLocations() {

                this.refreshContainer();

                let rects = this.container.flatMap(e => {
                    return e.locationsData();
                }).flatMap(e => {
                    return e.pageLocations;
                });
                return UserExperiorSDKType.utilities.js_utilities.serialize(rects);
            };

            /**
             * Output data for consumption
             * @returns {string}
             */
            snapshotInformation () {
                return JSON.stringify({
                    isScrolling     : this.monitor.isScrolling,
                    isZooming       : this.monitor.isZooming,
                    locationsToMask : this.maskedLocations(),
                    windowWidth     : window.innerWidth || document.documentElement.clientWidth
                });
            };
        };
    };

    /** SDK General set up
     */
    window.UserExperiorSDK = window.UserExperiorSDK || new UserExperiorSDKType();
    window.UserExperiorSDK.forceRefreshMaskLocations()
};
if (window.UserExperiorSDK) {
    window.UserExperiorSDK.snapshotInformation();
};
